#include <Arduino.h>
#include <WiFi.h>
#include <cmath>
#include "IMU.h"
#include "soc/soc.h"
#include "soc/rtc_cntl_reg.h"

// [네트워크 설정]
const char* ssid = "asia-edu_2G";
const char* password = "12345678";
WiFiServer server(8080);

// [핀 맵 설정]
const uint16_t PWMA = 26; const uint16_t AIN1 = 22; const uint16_t AIN2 = 23; 
const uint16_t PWMB = 25; const uint16_t BIN1 = 21; const uint16_t BIN2 = 17; 

// [제어 속도]
const int TURN_SPEED = 85; 

// [IMU 및 제어 변수]
EulerAngles stAngles;
IMU_ST_SENSOR_DATA_FLOAT stGyroRawData, stAccelRawData; 
IMU_ST_SENSOR_DATA stMagnRawData;

float target_turn_angle = 0.0;     
float gyro_z_offset = 0.0;         // 정지 상태 자이로 센서 오프셋 값
float gyro_accumulated_deg = 0.0;  // 무조건 수평 가정하에 누적할 Yaw 각도
bool is_turn_mode = false;

// [통신 버퍼 및 명령어 락]
String cmd_buffer = ""; 
String current_active_cmd = "x";

// 모터 제어 함수
void controlMotor(char motor, int speed) {
  uint16_t pwm = (motor == 'A') ? PWMA : PWMB;
  uint16_t in1 = (motor == 'A') ? AIN1 : BIN1;
  uint16_t in2 = (motor == 'A') ? AIN2 : BIN2;

  if (speed == 0) {
    digitalWrite(in1, HIGH);
    digitalWrite(in2, HIGH);
    ledcWrite(pwm, 0);
  } else {
    digitalWrite(in1, speed > 0 ? LOW : HIGH);
    digitalWrite(in2, speed > 0 ? HIGH : LOW);
    ledcWrite(pwm, min(abs(speed), 255));
  }
}

// 부팅 시 자이로 Z축의 정적 오차(영점)를 잡는 함수
void calibrateGyro() {
  float sum = 0;
  int samples = 400; 
  Serial.println(">> 자이로 보정 시작 (로봇을 움직이지 마세요)...");
  for (int i = 0; i < samples; i++) {
    imuDataGet(&stAngles, &stGyroRawData, &stAccelRawData, &stMagnRawData);
    sum += stGyroRawData.Z; // [수정] 대문자 Z로 변경
    delay(5);
  }
  gyro_z_offset = sum / samples;
  Serial.print(">> 자이로 Z축 정밀 영점 보정 완료 offset: ");
  Serial.println(gyro_z_offset);
}

void setup() {
  IPAddress local_IP(192, 168, 0, 9);
  IPAddress gateway(192, 168, 0, 1);
  IPAddress subnet(255, 255, 255, 0);
  
  WRITE_PERI_REG(RTC_CNTL_BROWN_OUT_REG, 0); 
  Serial.begin(115200);
  
  pinMode(AIN1, OUTPUT); pinMode(AIN2, OUTPUT);
  pinMode(BIN1, OUTPUT); pinMode(BIN2, OUTPUT);
  
  ledcAttach(PWMA, 20000, 8); 
  ledcAttach(PWMB, 20000, 8);
  
  if (!WiFi.config(local_IP, gateway, subnet)) {
    Serial.println("STA Failed to configure");
  }
  
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi 연결 성공!");
  server.begin();
  
  imuInit();
  delay(500);
  calibrateGyro(); // 초기 정밀 영점 설정
}

void loop() {
  WiFiClient client = server.available(); 
  if (client) {
    Serial.println("파이썬 단말기 연결됨");
    static unsigned long last_loop_time = 0;
    static unsigned long last_send = 0;

    while (client.connected()) {
      
      // 10ms(100Hz) 주기로 타이트하게 연산
      if (millis() - last_loop_time >= 10) {
        unsigned long current_time = millis();
        float dt = (current_time - last_loop_time) / 1000.0; 
        last_loop_time = current_time;

        // IMU raw 데이터 갱신
        imuDataGet(&stAngles, &stGyroRawData, &stAccelRawData, &stMagnRawData);

        // 무조건 수평이라고 가정하고 오직 Z축 회전 성분(각속도)만 대문자로 추출
        float gyro_z_deg_per_sec = stGyroRawData.Z - gyro_z_offset; // [수정] 대문자 Z로 변경

        // 데드밴드(Deadband) 필터 적용 및 회전 시 각도 적분
        if (is_turn_mode) {
          if (abs(gyro_z_deg_per_sec) > 0.1) {
            gyro_accumulated_deg += (gyro_z_deg_per_sec * dt);
          }
        }

        // 파이썬 명령 수신 처리
        while (client.available() > 0) {
          char c = client.read();
          if (c == '<') {
            cmd_buffer = "";
          } else if (c == '>') {
            if (cmd_buffer != current_active_cmd) {
              if (cmd_buffer.startsWith("t,")) {
                target_turn_angle = cmd_buffer.substring(2).toFloat();
                
                // 새로운 회전 명령이 올 때만 수평 적분 각도를 0으로 리셋
                gyro_accumulated_deg = 0.0;
                is_turn_mode = true;
                current_active_cmd = cmd_buffer; 
                Serial.println("회전 명령 접수 (수평 적분 모드): " + String(target_turn_angle));
              } else if (cmd_buffer == "x") {
                is_turn_mode = false;
                controlMotor('A', 0); controlMotor('B', 0);
                current_active_cmd = cmd_buffer; 
              }
            }
          } else {
            cmd_buffer += c;
          }
        }

        // 제자리 회전 제어 실행 판정
        if (is_turn_mode) {
          if (abs(gyro_accumulated_deg) >= abs(target_turn_angle)) {
            controlMotor('A', 0); controlMotor('B', 0); 
            is_turn_mode = false;
            Serial.print(">> [정지 완료] 최종 계산된 수평 회전각: ");
            Serial.println(gyro_accumulated_deg);
          } else {
            // 회전 상태 유지
            if (target_turn_angle > 0) {
              controlMotor('A', -TURN_SPEED); controlMotor('B', TURN_SPEED);
            } else {
              controlMotor('A', TURN_SPEED);  controlMotor('B', -TURN_SPEED);
            }
          }
        }
        
        // 파이썬 단말기로 데이터 전송 (50ms 주기)
        if (millis() - last_send > 50) {
          last_send = millis();
          // 파이썬 단말기에는 수평면 기준 누적 회전각(시작 시 0도)을 전송
          client.print("Yaw: " + String(gyro_accumulated_deg) + "\n");
        }
      }
    } 
    
    controlMotor('A', 0); controlMotor('B', 0);
    current_active_cmd = "x"; 
    Serial.println("파이썬 단말기 연결 끊김");
  }
}