#include <Arduino.h>
#include <WiFi.h>
#include <cmath>
#include "IMU.h" 

const char* ssid = "asia-edu_2G";
const char* password = "12345678";

WiFiServer server(8080); 

const uint16_t AENCA = 35; 
const uint16_t AENCB = 34; 
const uint16_t BENCA = 27; 
const uint16_t BENCB = 16; 

volatile long A_wheel_pulse_count = 0;
volatile long B_wheel_pulse_count = 0;
volatile int current_dir_A = 1;
volatile int current_dir_B = 1;

void IRAM_ATTR A_wheel_pulse() { A_wheel_pulse_count += current_dir_A; }
void IRAM_ATTR B_wheel_pulse() { B_wheel_pulse_count += current_dir_B; }

const uint16_t PWMA = 26; const uint16_t AIN1 = 22; const uint16_t AIN2 = 23; 
const uint16_t PWMB = 25; const uint16_t BIN1 = 21; const uint16_t BIN2 = 17; 

const int freq = 20000;      
const int resolution = 8;    

// [튜닝 1] 우측으로 7cm 쏠리는 현상을 예방하기 위해 물리적 기본 출력 매진 미세 교정
const float MOTOR_A_WEIGHT = 1.01; 
const float MOTOR_B_WEIGHT = 1.00; // 0.99 -> 1.00 상향 조정 (왼쪽 바퀴 힘 보강)

// ==========================================
// [튜닝 2] 353cm 도달 실측 기반 363cm 타겟 틱수 최종 보정
// ==========================================
const float TARGET_DISTANCE_CM = 363.0; 
const float TICKS_PER_CM = 725.875; // 실측 기반 최종 정밀 눈금 상수
const long TARGET_TICKS = (long)(TARGET_DISTANCE_CM * TICKS_PER_CM); // 마스터 타겟: 263,493 틱

EulerAngles stAngles;
IMU_ST_SENSOR_DATA_FLOAT stGyroRawData;
IMU_ST_SENSOR_DATA_FLOAT stAccelRawData;
IMU_ST_SENSOR_DATA stMagnRawData;

float gyroZ_offset = 0.0;     
float current_yaw = 0.0;      
float target_yaw = 0.0;       
unsigned long last_imu_time = 0; 
unsigned long last_send_time = 0; 

const float HEADING_KP = 1.2; 

String current_command = "x"; 
String inputBuffer = "";      
unsigned long lastCommandTime = 0;
const unsigned long TIMEOUT_MS = 1500; // 하트비트 유실 방어벽 유지

bool is_target_mode = false;
bool target_reached = false;

void setup() {
  delay(500); 
  Serial.begin(115200);
  
  pinMode(AENCA, INPUT_PULLUP); pinMode(AENCB, INPUT_PULLUP);
  pinMode(BENCA, INPUT_PULLUP); pinMode(BENCB, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(AENCB), A_wheel_pulse, RISING);
  attachInterrupt(digitalPinToInterrupt(BENCB), B_wheel_pulse, RISING);
  
  pinMode(AIN1, OUTPUT); pinMode(AIN2, OUTPUT);
  pinMode(BIN1, OUTPUT); pinMode(BIN2, OUTPUT);
  ledcAttach(PWMA, freq, resolution); ledcAttach(PWMB, freq, resolution);

  imuInit(); 

  Serial.println("\n>> [IMU] 정적 영점 보정 시작 (기체를 움직이지 마세요)...");
  float gyroZ_sum = 0.0;
  int samples = 100; 
  for (int i = 0; i < samples; i++) {
    imuDataGet(&stAngles, &stGyroRawData, &stAccelRawData, &stMagnRawData);
    gyroZ_sum += stGyroRawData.Z;
    delay(5);
  }
  gyroZ_offset = gyroZ_sum / samples;
  Serial.print(">> [IMU] 자이로 Z축 오프셋 확정: "); Serial.println(gyroZ_offset);

  Serial.print("Wi-Fi 연결 중: ");
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) { delay(500); Serial.print("."); }
  Serial.print("\n>> ESP32 IP 주소: "); Serial.println(WiFi.localIP()); 

  server.begin();
  last_imu_time = millis();
  lastCommandTime = millis();
}

void controlMotor(char motor, int speed) {
  uint16_t pwmPin = (motor == 'A') ? PWMA : PWMB;
  uint16_t in1Pin = (motor == 'A') ? AIN1 : BIN1;
  uint16_t in2Pin = (motor == 'A') ? AIN2 : BIN2;
  float weight = (motor == 'A') ? MOTOR_A_WEIGHT : MOTOR_B_WEIGHT;
  int balanced_speed = (int)(speed * weight);

  if (balanced_speed == 0) {
    digitalWrite(in1Pin, HIGH); digitalWrite(in2Pin, HIGH); ledcWrite(pwmPin, 0); // Short Brake 작동
  } else if (balanced_speed > 0) {
    digitalWrite(in1Pin, LOW); digitalWrite(in2Pin, HIGH); ledcWrite(pwmPin, min(balanced_speed, 255));
    if (motor == 'A') current_dir_A = 1; else current_dir_B = 1;
  } else {
    digitalWrite(in1Pin, HIGH); digitalWrite(in2Pin, LOW); ledcWrite(pwmPin, min(abs(balanced_speed), 255));
    if (motor == 'A') current_dir_A = -1; else current_dir_B = -1;
  }
}

void loop() {
  WiFiClient client = server.available(); 

  if (client) {
    inputBuffer = "";
    lastCommandTime = millis();
    last_imu_time = millis();
    last_send_time = millis();

    while (client.connected()) {
      unsigned long now = millis();
      float dt = (float)(now - last_imu_time) / 1000.0;
      
      if (dt >= 0.002) { 
        last_imu_time = now;
        imuDataGet(&stAngles, &stGyroRawData, &stAccelRawData, &stMagnRawData);
        float gyroZ_pure = stGyroRawData.Z - gyroZ_offset;
        
        if (dt < 0.2) {
          current_yaw += gyroZ_pure * dt; 
        }
      }

      while (client.available() > 0) {
        char c = client.read();
        if (c == '<') {
          inputBuffer = ""; 
        } else if (c == '>') {
          if (inputBuffer == "g") {
            lastCommandTime = millis(); 
            if (!is_target_mode && current_command != "ARRIVED") {
              is_target_mode = true;
              target_reached = false;
              
              if (current_command != "TIMEOUT_STOP") {
                noInterrupts(); A_wheel_pulse_count = 0; B_wheel_pulse_count = 0; interrupts();
                current_yaw = 0.0;
                target_yaw = 0.0; 
              }
              
              current_command = "g";
              controlMotor('A', 127); controlMotor('B', 127); 
            }
          } 
          else if (inputBuffer == "x") {
            lastCommandTime = millis();
            is_target_mode = false;
            target_reached = false;
            current_command = "x";
            controlMotor('A', 0); controlMotor('B', 0); 
          }
        } else {
          inputBuffer += c;
        }
      }

      if (is_target_mode && !target_reached) {
        if (abs(B_wheel_pulse_count) >= TARGET_TICKS) {
          controlMotor('A', 0); controlMotor('B', 0); 
          target_reached = true;
          is_target_mode = false;  
          current_command = "ARRIVED"; 
        } 
        else {
          float error = target_yaw - current_yaw; 

          while (error > 180.0) error -= 360.0;
          while (error <= -180.0) error += 360.0;

          float raw_correction = error * HEADING_KP; 
          int correction = constrain((int)raw_correction, -40, 40); 

          int speed_A = 127 + correction; 
          int speed_B = 127 - correction;

          speed_A = constrain(speed_A, 0, 255);
          speed_B = constrain(speed_B, 0, 255);

          controlMotor('A', speed_A); 
          controlMotor('B', speed_B);
        }
      }

      if (millis() - lastCommandTime > TIMEOUT_MS) {
        if (!target_reached && current_command != "ARRIVED") {
          controlMotor('A', 0); controlMotor('B', 0);
          current_command = "TIMEOUT_STOP";
          is_target_mode = false;
          target_reached = false;
        }
      }

      if (millis() - last_send_time >= 50) {
        last_send_time = millis();
        client.print("STATE: "); client.print(current_command);
        client.print(" | Target: "); client.print(TARGET_TICKS);
        client.print(" | Count A: "); client.print(A_wheel_pulse_count);
        client.print(" | Count B: "); client.print(B_wheel_pulse_count);
        client.print(" | Yaw: "); client.println(current_yaw);
      }
    }
    
    if (current_command != "ARRIVED") {
      is_target_mode = false; target_reached = false;
    }
    controlMotor('A', 0); controlMotor('B', 0);
  }
}