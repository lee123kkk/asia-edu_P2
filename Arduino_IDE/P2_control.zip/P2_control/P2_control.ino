#include <Arduino.h>
#include <cmath>
#include "IMU.h"
#include "soc/soc.h"
#include "soc/rtc_cntl_reg.h"

// ==========================================
// [핀 맵 설정] (모터 및 엔코더 핀 - UART와 충돌 없음)
// ==========================================
const uint16_t PWMA = 26; const uint16_t AIN1 = 22; const uint16_t AIN2 = 23;
const uint16_t PWMB = 25; const uint16_t BIN1 = 21; const uint16_t BIN2 = 17;
const uint16_t AENCA = 35; const uint16_t AENCB = 34;
const uint16_t BENCA = 27; const uint16_t BENCB = 16;

// ==========================================
// [엔코더 카운트 전역 변수]
// ==========================================
volatile long A_wheel_pulse_count = 0;
volatile long B_wheel_pulse_count = 0;
volatile int current_dir_A = 1;
volatile int current_dir_B = 1;

void IRAM_ATTR A_wheel_pulse() { A_wheel_pulse_count += current_dir_A; }
void IRAM_ATTR B_wheel_pulse() { B_wheel_pulse_count += current_dir_B; }

// ==========================================
// [물리 가중치 및 제어 게인 설정]
// ==========================================
const float MOTOR_A_WEIGHT = 1.01;
const float MOTOR_B_WEIGHT = 1.00;
const float HEADING_KP = 1.2;
const int TURN_SPEED = 85;

// ==========================================
// [제어 상태 및 센서 변수]
// ==========================================
enum RobotState { IDLE, DRIVE_STRAIGHT, TURN };
RobotState currentState = IDLE;

EulerAngles stAngles;
IMU_ST_SENSOR_DATA_FLOAT stGyroRawData, stAccelRawData;
IMU_ST_SENSOR_DATA stMagnRawData;

float target_yaw = 0.0;
float current_yaw = 0.0;
float gyro_z_offset = 0.0;
float gyro_accumulated_deg = 0.0;
float target_turn_angle = 0.0;

int current_speed = 0; 
String cmd_buffer = "";
String last_cmd = ""; // 중복 명령 필터링을 위해 직전 명령어를 저장하는 변수

// 🚨 통신 차단 안전 감시용 타임스탬프 (세이프가드)
unsigned long last_communication_time = 0;
const unsigned long SAFETY_TIMEOUT_MS = 2000; // 통신 두절 허용 시간 (2초)

// ==========================================
// [모터 액추에이팅 제어 함수]
// ==========================================
void controlMotor(char motor, int speed) {
  uint16_t pwm_pin, in1_pin, in2_pin;
  float weight = 1.0;
  if (motor == 'A') {
    pwm_pin = PWMA; in1_pin = AIN1; in2_pin = AIN2; weight = MOTOR_A_WEIGHT;
  } else {
    pwm_pin = PWMB; in1_pin = BIN1; in2_pin = BIN2; weight = MOTOR_B_WEIGHT;
  }

  int final_speed = constrain((int)(speed * weight), -255, 255);

  if (final_speed > 0) {
    digitalWrite(in1_pin, HIGH); digitalWrite(in2_pin, LOW);
    ledcWrite(pwm_pin, final_speed);
  } else if (final_speed < 0) {
    digitalWrite(in1_pin, LOW); digitalWrite(in2_pin, HIGH);
    ledcWrite(pwm_pin, abs(final_speed));
  } else {
    //  이 부분을 테스트용 코드처럼 강력 전자 브레이크(HIGH, HIGH)로 변경!
    digitalWrite(in1_pin, HIGH); 
    digitalWrite(in2_pin, HIGH); 
    ledcWrite(pwm_pin, 0);
  }
}

// ==========================================
// [자이로스코프 영점 교정]
// ==========================================
void calibrateGyro() {
  float sum = 0;
  int samples = 500;
  for (int i = 0; i < samples; i++) {
    imuDataGet(&stAngles, &stGyroRawData, &stAccelRawData, &stMagnRawData);
    sum += stGyroRawData.Z;
    delay(2);
  }
  gyro_z_offset = sum / samples;
}

// ==========================================
// [초기 설정]
// ==========================================
void setup() {
  WRITE_PERI_REG(RTC_CNTL_BROWN_OUT_REG, 0); 
  
  Serial.begin(115200); 
  delay(1000); // 시리얼 포트 안정화 대기
  
  Serial.println("\n\n============================");
  Serial.println(">> 1. ESP32 시스템 부팅 시작");
  Serial.println("============================");

  pinMode(AIN1, OUTPUT); pinMode(AIN2, OUTPUT);
  pinMode(BIN1, OUTPUT); pinMode(BIN2, OUTPUT);
  pinMode(AENCA, INPUT); pinMode(AENCB, INPUT);
  pinMode(BENCA, INPUT); pinMode(BENCB, INPUT);
  attachInterrupt(digitalPinToInterrupt(AENCA), A_wheel_pulse, RISING);
  attachInterrupt(digitalPinToInterrupt(BENCA), B_wheel_pulse, RISING);

  ledcAttach(PWMA, 20000, 8);
  ledcAttach(PWMB, 20000, 8);
  
  Serial.println(">> 2. 모터 및 엔코더 초기화 완료");
  Serial.println(">> 3. IMU(자이로) 센서 초기화 시도 중... (여기서 멈추면 IMU 연결 불량)");
  
  imuInit();
  
  Serial.println(">> 4. IMU 초기화 통과! 영점 보정 시작...");
  delay(500);
  calibrateGyro();

  Serial.println(">> 5. 영점 보정 완료. 메인 루프 진입 준비 끝!");
  last_communication_time = millis();
}

// ==========================================
// [메인 제어 루프]
// ==========================================
void loop() {
  // 자이로 누적 적분을 위한 마이크로초 기반 정밀 시간 변화량 계산
  static unsigned long last_loop_time = 0;
  unsigned long now = micros();
  if (last_loop_time == 0) last_loop_time = now;
  float dt = (now - last_loop_time) / 1000000.0;
  last_loop_time = now;

  imuDataGet(&stAngles, &stGyroRawData, &stAccelRawData, &stMagnRawData);
  float gyro_z_deg_per_sec = (stGyroRawData.Z - gyro_z_offset);

  // 1. 명령어 패킷 스트림 분석 (라즈베리파이 시리얼 통신)
  while (Serial.available() > 0) {
    char c = Serial.read();
    
    // 패킷의 바이트가 하나라도 감지되면 생존 신호 타임스탬프 상시 갱신
    last_communication_time = millis(); 

    if (c == '<') {
      cmd_buffer = "";
    } else if (c == '>') {
      // 🛠️ 핵심 해결책: 새로 수신한 명령이 이전 명령과 다를 때만 실행 파싱 진입
      if (cmd_buffer != last_cmd) { 
        // [명령 1] 즉시 정지 명령
        if (cmd_buffer == "s") {
          currentState = IDLE;
          controlMotor('A', 0); controlMotor('B', 0);
          last_cmd = cmd_buffer;
        } 
        // [명령 2] 가변 속도 직진 명령 (예: <g,150>)
        else if (cmd_buffer.startsWith("g,")) {
          current_speed = cmd_buffer.substring(2).toInt();
          target_yaw = current_yaw; // 구동 명령 접수 순시 기수 락온
          currentState = DRIVE_STRAIGHT;
          last_cmd = cmd_buffer;
        } 
        // [명령 3] 정밀 제자리 회전 명령 (예: <t,-90>)
        else if (cmd_buffer.startsWith("t,")) {
          target_turn_angle = cmd_buffer.substring(2).toFloat();
          gyro_accumulated_deg = 0.0; // 오직 새로운 회전 명령이 처음 들어왔을 때만 각도 누적값 리셋!
          currentState = TURN;
          last_cmd = cmd_buffer;
        }
      }
      cmd_buffer = ""; 
    } else {
      cmd_buffer += c;
    }
  }

  // 2. 🚨 통신 두절 세이프가드 (라즈베리파이 비정상 종료 및 통신 단선 시 2초 후 자동 비상 제동)
  if (millis() - last_communication_time > SAFETY_TIMEOUT_MS) {
    if (currentState != IDLE) {
      controlMotor('A', 0); controlMotor('B', 0);
      currentState = IDLE;
      last_cmd = ""; // 통신 리셋 시 명령 캐시도 클리어
    }
  }

  // 3. 주행 상태 머신 및 실시간 피드백 액추에이팅
  if (currentState == DRIVE_STRAIGHT) {
    current_yaw += (gyro_z_deg_per_sec * dt); // 실시간 헤딩각 누적 추적
    
    float error = target_yaw - current_yaw;
    while (error > 180.0) error -= 360.0;
    while (error <= -180.0) error += 360.0;
    
    // 타겟 속도 기준 좌우 모터 편차 실시간 PID 제어
    int correction = constrain((int)(error * HEADING_KP), -40, 40);
    int speed_A = constrain(current_speed + correction, 0, 255);
    int speed_B = constrain(current_speed - correction, 0, 255);
    
    controlMotor('A', speed_A); controlMotor('B', speed_B);
  } 
  else if (currentState == TURN) {
    // 0.1도 정적 노이즈 데드밴드 필터 가동
    if (abs(gyro_z_deg_per_sec) > 0.1) {
      gyro_accumulated_deg += (gyro_z_deg_per_sec * dt);
    }
    
    // 중복 명령 무시 로직 덕분에 각도가 가로막히지 않고 순수하게 누적되어 목표치 판정 가능
    if (abs(gyro_accumulated_deg) >= abs(target_turn_angle)) {
      controlMotor('A', 0); controlMotor('B', 0);
      currentState = IDLE;
      last_cmd = "s"; // 회전 임무 완수 후 대기상태 패킷 매칭을 위해 내부 캐시 변경
    } else {
      if (target_turn_angle > 0) { 
        controlMotor('A', -TURN_SPEED); controlMotor('B', TURN_SPEED);
      } else { 
        controlMotor('A', TURN_SPEED);  controlMotor('B', -TURN_SPEED);
      }
    }
  }

  // 4. 라즈베리파이로 상태 피드백 실시간 전송 (50ms 주기)
  static unsigned long last_send_time = 0;
  if (millis() - last_send_time >= 50) {
    last_send_time = millis();
    Serial.print("MODE: ");
    if(currentState == IDLE) Serial.print("IDLE");
    else if(currentState == DRIVE_STRAIGHT) Serial.print("DRIVE");
    else if(currentState == TURN) Serial.print("TURN");

    Serial.print(" | Yaw: "); Serial.print(current_yaw);
    Serial.print(" | TurnAng: "); Serial.println(gyro_accumulated_deg);
  }

  delay(1); 
}